<?php
include_once 'model/config.php';
include_once 'model/product.php';
include 'view/header.php';

include 'view/footer.php';

?>