<?php

$ranges = array(3774873600 => array(4043309055, 'ZZ'));
