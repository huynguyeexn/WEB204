<?php

$ranges = array(3909091328 => array(4177526783, 'ZZ'));
