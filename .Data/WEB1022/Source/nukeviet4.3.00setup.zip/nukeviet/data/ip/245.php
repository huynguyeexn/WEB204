<?php

$ranges = array(3858759680 => array(4127195135, 'ZZ'));
