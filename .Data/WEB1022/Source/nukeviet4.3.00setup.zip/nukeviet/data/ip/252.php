<?php

$ranges = array(3976200192 => array(4244635647, 'ZZ'));
