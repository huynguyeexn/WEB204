<?php

$ranges = array(3959422976 => array(4227858431, 'ZZ'));
