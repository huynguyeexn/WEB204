<?php

$ranges = array(3892314112 => array(4160749567, 'ZZ'));
