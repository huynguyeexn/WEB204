<?php

$ranges = array();
