<?php

$ranges = array(671088640 => array(683671551, 'US'), 679477248 => array(687865855, 'US'));
