<?php

$ranges = array(184549376 => array(218103807, 'US'));
