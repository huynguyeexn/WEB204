<?php

$ranges = array(3925868544 => array(4194303999, 'ZZ'));
