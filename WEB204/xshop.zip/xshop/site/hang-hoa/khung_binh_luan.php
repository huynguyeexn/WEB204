<form action="<?=$_SERVER["REQUEST_URI"]?>" method="post">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-sm-10">
                                <input name="noi_dung" class="form-control"/>
                            </div>
                            <div class="col-sm-2">
                                <button class="btn btn-default" style="width: 100%">Gửi</button>
                            </div>
                        </div>
                    </div>
                </form>      