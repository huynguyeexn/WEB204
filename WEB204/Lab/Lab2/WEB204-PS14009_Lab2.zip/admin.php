<?php
$ctrl = "admin";
if(isset($_GET["ctrl"])){
    $ctrl = $_GET["ctrl"];
}

include_once "views/admin/admin-header.php";
include_once "controllers/$ctrl.php";
include_once "views/admin/admin-footer.php";
