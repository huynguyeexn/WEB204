<?php
include_once "models/user.php";
include_once "models/order.php";
$act = "index";
$message = "";
if(isset($_GET["act"])){
    $act = $_GET["act"];
}
switch($act){
    case "index":
        $orders = getAllOrders();
        include_once "views/admin/order/order.php";
    break;

    case "add":
        include "views/admin/order/add-order.php";
    break;

    case "insert":
        $name = $_POST["orderName"];
        addNewOrder($name);
        $message = "Success";
        include "views/admin/order/order.php";
    break;

    case "edit":
        if(isset($_GET["id"])){
            $id = $_GET["id"];
            $order = getOrderById($id);
            include "views/admin/order/edit-order.php";
        }
    break;

    case "update":
        $name = $_POST["orderName"];
        $id = $_POST["orderID"];
        updateOrder($id, $name);
        $message = "Success";
        include "views/admin/order/order.php";
    break;
}